from __future__ import annotations

import math
from typing import Any, Iterable

import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
from transformers import AutoModel, AutoTokenizer

from .data import Seq2SeqCollator, move_to_device


def simple_tokens(text: str) -> list[str]:
    return [tok for tok in text.strip().split() if tok]


def novelty_ratio(source: str, target: str) -> float:
    source_set = set(simple_tokens(source))
    target_tokens = simple_tokens(target)
    if not target_tokens:
        return 0.0
    novel = sum(1 for tok in target_tokens if tok not in source_set)
    return novel / len(target_tokens)


def rouge_l_f1(candidate: str, reference: str) -> float:
    cand = simple_tokens(candidate)
    ref = simple_tokens(reference)
    if not cand or not ref:
        return 0.0

    prev = [0] * (len(ref) + 1)
    for c_tok in cand:
        curr = [0]
        for j, r_tok in enumerate(ref, start=1):
            if c_tok == r_tok:
                curr.append(prev[j - 1] + 1)
            else:
                curr.append(max(curr[-1], prev[j]))
        prev = curr

    lcs = prev[-1]
    precision = lcs / len(cand)
    recall = lcs / len(ref)
    if precision + recall == 0:
        return 0.0
    return 2 * precision * recall / (precision + recall)


def basic_text_features(source: str, target: str) -> dict[str, float]:
    source_words = simple_tokens(source)
    target_words = simple_tokens(target)
    source_len = len(source_words)
    target_len = len(target_words)
    return {
        "source_chars": float(len(source)),
        "target_chars": float(len(target)),
        "source_words": float(source_len),
        "target_words": float(target_len),
        "compression_ratio": float(target_len / max(source_len, 1)),
        "novelty_ratio": float(novelty_ratio(source, target)),
    }


def batched(items: list[Any], batch_size: int) -> Iterable[list[Any]]:
    for start in range(0, len(items), batch_size):
        yield items[start : start + batch_size]


def teacher_distribution_features(
    model: Any,
    tokenizer: Any,
    records: list[dict[str, Any]],
    device: torch.device,
    batch_size: int = 4,
    max_source_length: int = 512,
    max_target_length: int = 128,
    desc: str = "teacher stats",
) -> list[dict[str, float]]:
    collator = Seq2SeqCollator(tokenizer, max_source_length, max_target_length)
    stats: list[dict[str, float]] = []
    model.eval()

    total = math.ceil(len(records) / batch_size) if records else 0
    with torch.no_grad():
        for chunk in tqdm(batched(records, batch_size), total=total, desc=desc):
            batch = move_to_device(collator(chunk), device)
            labels = batch["labels"]
            outputs = model(**batch)
            probs = F.softmax(outputs.logits.float(), dim=-1)
            entropy = -(probs * probs.clamp_min(1e-12).log()).sum(dim=-1)
            top2 = probs.topk(k=2, dim=-1).values
            max_prob = top2[..., 0]
            margin = top2[..., 0] - top2[..., 1]
            mask = labels.ne(-100)

            for row_idx in range(labels.size(0)):
                row_mask = mask[row_idx]
                denom = row_mask.sum().clamp_min(1)
                stats.append(
                    {
                        "teacher_entropy": float((entropy[row_idx] * row_mask).sum().item() / denom.item()),
                        "teacher_max_prob": float((max_prob[row_idx] * row_mask).sum().item() / denom.item()),
                        "teacher_margin": float((margin[row_idx] * row_mask).sum().item() / denom.item()),
                    }
                )
    return stats


def generate_teacher_summaries(
    model: Any,
    tokenizer: Any,
    records: list[dict[str, Any]],
    device: torch.device,
    batch_size: int = 4,
    max_source_length: int = 512,
    max_new_tokens: int = 128,
    num_beams: int = 4,
    desc: str = "teacher summaries",
) -> list[str]:
    summaries: list[str] = []
    model.eval()

    total = math.ceil(len(records) / batch_size) if records else 0
    with torch.no_grad():
        for chunk in tqdm(batched(records, batch_size), total=total, desc=desc):
            texts = [item["source"] for item in chunk]
            enc = tokenizer(
                texts,
                max_length=max_source_length,
                truncation=True,
                padding=True,
                return_tensors="pt",
            )
            enc = move_to_device(enc, device)
            generated = model.generate(
                **enc,
                max_new_tokens=max_new_tokens,
                num_beams=num_beams,
            )
            summaries.extend(tokenizer.batch_decode(generated, skip_special_tokens=True))
    return summaries


def _mean_pool(last_hidden_state: torch.Tensor, attention_mask: torch.Tensor) -> torch.Tensor:
    mask = attention_mask.unsqueeze(-1).float()
    return (last_hidden_state * mask).sum(dim=1) / mask.sum(dim=1).clamp_min(1.0)


def semantic_similarity_scores(
    model_name: str,
    pairs: list[tuple[str, str]],
    device: torch.device,
    batch_size: int = 8,
    max_length: int = 256,
) -> list[float]:
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(device)
    model.eval()
    scores: list[float] = []

    total = math.ceil(len(pairs) / batch_size) if pairs else 0
    with torch.no_grad():
        for chunk in tqdm(batched(pairs, batch_size), total=total, desc="semantic agreement"):
            left = [item[0] for item in chunk]
            right = [item[1] for item in chunk]
            left_enc = tokenizer(left, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
            right_enc = tokenizer(right, padding=True, truncation=True, max_length=max_length, return_tensors="pt")
            left_enc = move_to_device(left_enc, device)
            right_enc = move_to_device(right_enc, device)
            left_out = model(**left_enc)
            right_out = model(**right_enc)
            left_vec = _mean_pool(left_out.last_hidden_state, left_enc["attention_mask"])
            right_vec = _mean_pool(right_out.last_hidden_state, right_enc["attention_mask"])
            sims = F.cosine_similarity(left_vec, right_vec, dim=-1)
            scores.extend(float(x) for x in sims.detach().cpu())
    return scores


def build_feature_rows(
    records: list[dict[str, Any]],
    teacher_stats: list[dict[str, float]] | None = None,
    teacher_summaries: list[str] | None = None,
    semantic_scores: list[float] | None = None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    teacher_stats = teacher_stats or [{} for _ in records]
    teacher_summaries = teacher_summaries or ["" for _ in records]
    semantic_scores = semantic_scores or [math.nan for _ in records]

    for record, stats, teacher_summary, semantic_score in zip(
        records, teacher_stats, teacher_summaries, semantic_scores
    ):
        row: dict[str, Any] = {
            "id": record["id"],
            **basic_text_features(record["source"], record["target"]),
            **stats,
            "gold_teacher_rouge_l": rouge_l_f1(teacher_summary, record["target"]) if teacher_summary else math.nan,
            "semantic_agreement": float(semantic_score) if not np.isnan(semantic_score) else math.nan,
        }
        rows.append(row)
    return rows
